"use client"

import HBCreatorWorkflow from "@/components/hb-creator-workflow"

export default function HomePage() {
  return <HBCreatorWorkflow />
}